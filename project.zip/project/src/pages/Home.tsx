import React from 'react';
import { Link } from 'react-router-dom';
import { Stethoscope, Upload, BarChart, MessageSquare, Shield, Zap, Users, Server } from 'lucide-react';

const Home: React.FC = () => {
  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="py-12 md:py-20 bg-gradient-to-br from-primary-600 to-secondary-700 text-white">
        <div className="container mx-auto px-4 text-center">
          <h1 className="text-3xl md:text-5xl font-bold mb-6 animate-fade-in">
            AI-Powered Pneumonia Detection
          </h1>
          <p className="text-lg md:text-xl mb-8 max-w-3xl mx-auto text-gray-100 animate-slide-up">
            MedScanX uses cutting-edge artificial intelligence to detect pneumonia 
            from chest X-rays with high accuracy, providing faster diagnosis and treatment.
          </p>
          <div className="flex flex-col sm:flex-row justify-center gap-4 animate-slide-up">
            <Link to="/signup" className="bg-white text-primary-700 hover:bg-gray-100 font-medium py-3 px-6 rounded-lg transition-colors">
              Get Started
            </Link>
            <Link to="/login" className="border border-white text-white hover:bg-white hover:bg-opacity-10 font-medium py-3 px-6 rounded-lg transition-colors">
              Log In
            </Link>
          </div>
        </div>
      </section>

      {/* How It Works */}
      <section className="py-16 bg-white" id="features">
        <div className="container mx-auto px-4">
          <h2 className="text-2xl md:text-3xl font-bold text-center mb-12 text-gray-800">
            How MedScanX Works
          </h2>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {/* Step 1 */}
            <div className="card p-6 flex flex-col items-center text-center">
              <div className="bg-primary-100 p-4 rounded-full mb-4">
                <Upload className="h-8 w-8 text-primary-600" />
              </div>
              <h3 className="text-xl font-semibold mb-3 text-gray-800">Upload X-Ray</h3>
              <p className="text-gray-600">
                Simply upload a chest X-ray image through our secure platform.
                We support all standard medical image formats.
              </p>
            </div>
            
            {/* Step 2 */}
            <div className="card p-6 flex flex-col items-center text-center">
              <div className="bg-primary-100 p-4 rounded-full mb-4">
                <Server className="h-8 w-8 text-primary-600" />
              </div>
              <h3 className="text-xl font-semibold mb-3 text-gray-800">AI Analysis</h3>
              <p className="text-gray-600">
                Our advanced AI model analyzes the image, identifying patterns 
                associated with pneumonia with high accuracy.
              </p>
            </div>
            
            {/* Step 3 */}
            <div className="card p-6 flex flex-col items-center text-center">
              <div className="bg-primary-100 p-4 rounded-full mb-4">
                <BarChart className="h-8 w-8 text-primary-600" />
              </div>
              <h3 className="text-xl font-semibold mb-3 text-gray-800">Get Results</h3>
              <p className="text-gray-600">
                Receive detailed results within seconds, including detection 
                confidence and the option to consult with our AI assistant.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Features */}
      <section className="py-16 bg-gray-50">
        <div className="container mx-auto px-4">
          <h2 className="text-2xl md:text-3xl font-bold text-center mb-12 text-gray-800">
            Key Features
          </h2>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {/* Feature 1 */}
            <div className="flex items-start">
              <div className="bg-primary-100 p-3 rounded-lg mr-4">
                <Zap className="h-6 w-6 text-primary-600" />
              </div>
              <div>
                <h3 className="text-xl font-semibold mb-2 text-gray-800">Fast Detection</h3>
                <p className="text-gray-600">
                  Get results in seconds, not days. Our AI model delivers rapid 
                  pneumonia detection to accelerate the diagnostic process.
                </p>
              </div>
            </div>
            
            {/* Feature 2 */}
            <div className="flex items-start">
              <div className="bg-primary-100 p-3 rounded-lg mr-4">
                <Shield className="h-6 w-6 text-primary-600" />
              </div>
              <div>
                <h3 className="text-xl font-semibold mb-2 text-gray-800">Secure Platform</h3>
                <p className="text-gray-600">
                  Your data is protected with enterprise-grade security. 
                  We ensure all medical information remains private and secure.
                </p>
              </div>
            </div>
            
            {/* Feature 3 */}
            <div className="flex items-start">
              <div className="bg-primary-100 p-3 rounded-lg mr-4">
                <MessageSquare className="h-6 w-6 text-primary-600" />
              </div>
              <div>
                <h3 className="text-xl font-semibold mb-2 text-gray-800">AI Assistant</h3>
                <p className="text-gray-600">
                  Interact with our medical AI assistant to ask questions about 
                  your results and get informative responses.
                </p>
              </div>
            </div>
            
            {/* Feature 4 */}
            <div className="flex items-start">
              <div className="bg-primary-100 p-3 rounded-lg mr-4">
                <Users className="h-6 w-6 text-primary-600" />
              </div>
              <div>
                <h3 className="text-xl font-semibold mb-2 text-gray-800">Shared Access</h3>
                <p className="text-gray-600">
                  Easily share results with healthcare providers or family members 
                  through our secure sharing system.
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 bg-gradient-to-br from-accent-600 to-accent-800 text-white">
        <div className="container mx-auto px-4 text-center">
          <div className="max-w-3xl mx-auto">
            <Stethoscope className="h-16 w-16 mx-auto mb-6 text-white opacity-80" />
            <h2 className="text-2xl md:text-4xl font-bold mb-6">
              Ready to Experience the Future of Medical Diagnostics?
            </h2>
            <p className="text-lg mb-8 text-gray-100">
              Join thousands of users who are already benefiting from our 
              AI-powered pneumonia detection technology.
            </p>
            <Link to="/signup" className="bg-white text-accent-700 hover:bg-gray-100 font-medium py-3 px-8 rounded-lg inline-block transition-colors">
              Sign Up Now
            </Link>
          </div>
        </div>
      </section>

      {/* About Section */}
      <section className="py-16 bg-white" id="about">
        <div className="container mx-auto px-4">
          <div className="max-w-3xl mx-auto text-center">
            <h2 className="text-2xl md:text-3xl font-bold mb-6 text-gray-800">
              About MedScanX
            </h2>
            <p className="text-gray-600 mb-6">
              MedScanX was founded with a mission to make pneumonia detection faster, 
              more accurate, and accessible to everyone. Our team of AI researchers and 
              medical professionals has developed a state-of-the-art deep learning model 
              trained on thousands of X-ray images.
            </p>
            <p className="text-gray-600">
              By combining cutting-edge technology with medical expertise, we're 
              revolutionizing how pneumonia is detected and diagnosed, potentially 
              saving lives through early detection and treatment.
            </p>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Home;