from django.http import JsonResponse, FileResponse
from django.views.decorators.csrf import csrf_exempt
from gtts import gTTS
from langchain_groq import ChatGroq
from langchain.memory import ConversationBufferMemory
from langchain.chains import ConversationalRetrievalChain
from langchain.embeddings import HuggingFaceEmbeddings
from langchain.text_splitter import CharacterTextSplitter
from langchain.vectorstores import FAISS
from langchain_core.prompts import ChatPromptTemplate
import os
import tempfile
import speech_recognition as sr
from pydub import AudioSegment
from dotenv import load_dotenv

load_dotenv()
GROQ_API_KEY = os.getenv("GROQ_API_KEY")

# Persistent memory and chain setup
memory = ConversationBufferMemory(memory_key="chat_history", return_messages=True, output_key="answer")

# Dummy vector store setup
def get_vectorstore():
    text = "Your document content here."
    chunks = CharacterTextSplitter(chunk_size=900, chunk_overlap=100).split_text(text)
    embeddings = HuggingFaceEmbeddings(model_name="all-MiniLM-L6-v2")
    return FAISS.from_texts(chunks, embeddings)

retriever = get_vectorstore().as_retriever()

@csrf_exempt
def voice_chat(request):
    if request.method == "POST" and "audio" in request.FILES:
        language = request.POST.get("language", "en")  # Get language from request, default to English
        audio_file = request.FILES["audio"]
        with tempfile.NamedTemporaryFile(delete=False, suffix=".webm") as tmp_input:
            tmp_input.write(audio_file.read())
            tmp_input_path = tmp_input.name

        try:
            # Convert WebM to WAV using pydub
            audio = AudioSegment.from_file(tmp_input_path, format="webm")
            tmp_wav_path = tmp_input_path.replace(".webm", ".wav")
            audio.export(tmp_wav_path, format="wav")

            # Speech recognition
            recognizer = sr.Recognizer()
            with sr.AudioFile(tmp_wav_path) as source:
                audio_data = recognizer.record(source)
                try:
                    # Recognize speech in the selected language
                    recog_lang = 'ur-PK' if language == 'ur' else 'en-US'
                    text = recognizer.recognize_google(audio_data, language=recog_lang)
                except sr.UnknownValueError:
                    return JsonResponse({"error": "Speech not recognized."}, status=400)
        except Exception as e:
            return JsonResponse({"error": f"Audio processing failed: {str(e)}"}, status=500)

        # Dynamically set the prompt template based on language
        if language == 'ur':
            template = """You are a helpful assistant. Respond only in Urdu.\nContext: {context}\nChat History:\n{chat_history}\nHuman: {question}\nAssistant:"""
        else:
            template = """You are a helpful assistant. Respond only in English.\nContext: {context}\nChat History:\n{chat_history}\nHuman: {question}\nAssistant:"""
        prompt = ChatPromptTemplate.from_template(template)
        conversation_chain = ConversationalRetrievalChain.from_llm(
            llm=ChatGroq(groq_api_key=GROQ_API_KEY, model_name="llama3-70b-8192"),
            retriever=retriever,
            memory=memory,
            return_source_documents=True,
            combine_docs_chain_kwargs={"prompt": prompt}
        )

        # LLM response (let the model respond in the selected language)
        response = conversation_chain({
            "question": text,
            "chat_history": memory.chat_memory.messages
        })
        answer = response["answer"]

        # Text-to-speech in the selected language
        tts_lang = 'ur' if language == 'ur' else 'en'
        tts = gTTS(text=answer, lang=tts_lang)
        response_audio = tempfile.NamedTemporaryFile(delete=False, suffix=".mp3")
        tts.save(response_audio.name)

        return FileResponse(open(response_audio.name, "rb"), content_type="audio/mpeg")

    return JsonResponse({"error": "Invalid request."}, status=400)

@csrf_exempt
def text_chat(request):
    if request.method == "POST":
        import json
        data = json.loads(request.body)
        question = data.get("question", "")
        language = data.get("language", "en")
        if not question:
            return JsonResponse({"error": "No question provided."}, status=400)

        # Dynamically set the prompt template based on language
        if language == 'ur':
            template = """You are a helpful assistant. Respond only in Urdu.\nContext: {context}\nChat History:\n{chat_history}\nHuman: {question}\nAssistant:"""
        else:
            template = """You are a helpful assistant. Respond only in English.\nContext: {context}\nChat History:\n{chat_history}\nHuman: {question}\nAssistant:"""
        prompt = ChatPromptTemplate.from_template(template)
        conversation_chain = ConversationalRetrievalChain.from_llm(
            llm=ChatGroq(groq_api_key=GROQ_API_KEY, model_name="llama3-70b-8192"),
            retriever=retriever,
            memory=memory,
            return_source_documents=True,
            combine_docs_chain_kwargs={"prompt": prompt}
        )

        # LLM response
        response = conversation_chain({
            "question": question,
            "chat_history": memory.chat_memory.messages
        })
        answer = response["answer"]
        return JsonResponse({"answer": answer})

    return JsonResponse({"error": "Invalid request."}, status=400)
