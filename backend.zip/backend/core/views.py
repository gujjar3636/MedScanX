# # backend/core/views.py
# import os
# import torch
# from django.http import JsonResponse
# from django.views.decorators.csrf import csrf_exempt
# from django.conf import settings
# from django.core.files.storage import default_storage
# from PIL import Image, ImageDraw
# from torchvision import transforms
# from model.MSR import MSR

# # Load model
# model_path = os.path.join(settings.BASE_DIR, 'best_model.pth')
# model = MSR(layers=50, num_classes=3)  # Update if trained with 101 layers
# model.load_state_dict(torch.load(model_path, map_location=torch.device('cpu')))
# model.eval()

# # Transform to match training config
# transform = transforms.Compose([
#     transforms.Resize((512, 512)),
#     transforms.ToTensor(),
#     transforms.Normalize(mean=[0.485, 0.456, 0.406],
#                          std=[0.229, 0.224, 0.225])
# ])

# # Dummy label mapping (adjust to match actual dataset)
# label_map = {
#     0: "Normal",
#     1: "bronchial",
#     2: "loabar"
# }

# @csrf_exempt
# def detect(request):
#     if request.method == 'GET':
#         return JsonResponse({'message': 'hello from server'})
#     if request.method == 'POST' and request.FILES.get('image'):
#         image_file = request.FILES['image']
#         image_path = default_storage.save(f"input/{image_file.name}", image_file)
#         full_image_path = os.path.join(settings.MEDIA_ROOT, image_path)

#         image = Image.open(full_image_path).convert('RGB')
#         input_tensor = transform(image).unsqueeze(0)  # Add batch dimension

#         with torch.no_grad():
#             outputs = model(input_tensor)
#             _, predicted = torch.max(outputs, 1)
#             predicted_label = label_map.get(predicted.item(), "Unknown")

#         # Draw result label on image
#         draw = ImageDraw.Draw(image)
#         draw.text((10, 10), f"Detected: {predicted_label}", fill=(255, 0, 0))

#         output_path = os.path.join('output', image_file.name)
#         full_output_path = os.path.join(settings.MEDIA_ROOT, output_path)
#         os.makedirs(os.path.dirname(full_output_path), exist_ok=True)
#         image.save(full_output_path)

#         return JsonResponse({
#             'result': predicted_label,
#             'image_url': f"/media/{output_path}"
#         })

#     return JsonResponse({'error': 'Invalid request'}, status=400)





# backend/core/views.py

import os
import torch
from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt
from django.conf import settings
from django.core.files.storage import default_storage
from PIL import Image, ImageDraw
from torchvision import transforms
from model.MSR import MSR
from django.core.mail import send_mail
from .models import XRayResult
from django.views.decorators.http import require_GET
from django.forms.models import model_to_dict

# Load trained model (4-class)
model_path = os.path.join(settings.BASE_DIR, 'best_model.pth')
model = MSR(layers=50, num_classes=4)  # Ensure this matches your training
model.load_state_dict(torch.load(model_path, map_location=torch.device('cpu')))
model.eval()

# Transform to match training preprocessing
transform = transforms.Compose([
    transforms.Resize((512, 512)),
    transforms.ToTensor(),
    transforms.Normalize(mean=[0.485, 0.456, 0.406],
                         std=[0.229, 0.224, 0.225])
])

# Label mapping (based on alphabetical folder order)
label_map = {
    0: "Bacterial Pneumonia",
    1: "COVID-19",
    2: "Normal",
    3: "Viral Pneumonia"
}

@csrf_exempt
def detect(request):
    if request.method == 'GET':
        return JsonResponse({'message': 'hello from server'})

    if request.method == 'POST' and request.FILES.get('image'):
        # Save uploaded image
        image_file = request.FILES['image']
        image_path = default_storage.save(f"input/{image_file.name}", image_file)
        full_image_path = os.path.join(settings.MEDIA_ROOT, image_path)

        # Open and preprocess image
        image = Image.open(full_image_path).convert('RGB')
        input_tensor = transform(image).unsqueeze(0)  # Add batch dimension

        # Perform inference
        with torch.no_grad():
            outputs = model(input_tensor)
            _, predicted = torch.max(outputs, 1)
            predicted_label = label_map.get(predicted.item(), "Unknown")

        # Draw prediction on image
        draw = ImageDraw.Draw(image)
        draw.text((10, 10), f"Detected: {predicted_label}", fill=(255, 0, 0))

        # Save output image
        output_path = os.path.join('output', image_file.name)
        full_output_path = os.path.join(settings.MEDIA_ROOT, output_path)
        os.makedirs(os.path.dirname(full_output_path), exist_ok=True)
        image.save(full_output_path)

        # Get username from POST data
        username = request.POST.get('username')
        # Save result to database
        XRayResult.objects.create(
            image_path=output_path,
            result=predicted_label,
            user=username
        )

        # Return response
        return JsonResponse({
            'result': predicted_label,
            'image_url': f"/media/{output_path}"
        })

    return JsonResponse({'error': 'Invalid request'}, status=400)

@csrf_exempt
def contact_us(request):
    if request.method == 'POST':
        import json
        try:
            data = json.loads(request.body)
            name = data.get('name')
            email = data.get('email')
            subject = data.get('subject')
            message = data.get('message')
            if not (name and email and subject and message):
                return JsonResponse({'error': 'All fields are required.'}, status=400)
            full_message = f"From: {name} <{email}>\n\n{message}"
            send_mail(
                subject=subject,
                message=full_message,
                from_email=settings.DEFAULT_FROM_EMAIL,
                recipient_list=[settings.DEFAULT_FROM_EMAIL],
                fail_silently=False,
            )
            return JsonResponse({'success': 'Message sent successfully.'})
        except Exception as e:
            return JsonResponse({'error': str(e)}, status=500)
    return JsonResponse({'error': 'Invalid request method.'}, status=405)

@require_GET
@csrf_exempt
def xray_results_api(request):
    results = XRayResult.objects.all().order_by('-uploaded_at')
    data = [model_to_dict(r) for r in results]
    return JsonResponse(data, safe=False)
