import React, { useState, useEffect } from 'react';
import { useParams, useNavigate, Link } from 'react-router-dom';
import { 
  FileText, MessageSquare, Download, Share2, ChevronRight, 
  Printer, AlertTriangle, Check, X, PieChart, BarChart, Activity, User 
} from 'lucide-react';

// Mock data for demonstration
const mockResult = {
  id: '1',
  xRayId: 'X1234',
  userId: 'user123',
  patientName: 'John Doe',
  patientAge: 45,
  imageUrl: 'https://images.pexels.com/photos/4226119/pexels-photo-4226119.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1',
  result: 'Negative',
  confidence: 0.92,
  details: 'No signs of pneumonia detected. The lungs appear clear without significant opacities or consolidations. The heart size is normal, and the costophrenic angles are sharp.',
  date: new Date(2023, 9, 15),
  findings: [
    { area: 'Right Upper Lobe', finding: 'Clear', severity: 'None' },
    { area: 'Right Middle Lobe', finding: 'Clear', severity: 'None' },
    { area: 'Right Lower Lobe', finding: 'Clear', severity: 'None' },
    { area: 'Left Upper Lobe', finding: 'Clear', severity: 'None' },
    { area: 'Left Lower Lobe', finding: 'Minor opacity', severity: 'Mild' },
  ],
  recommendations: [
    'No further action required',
    'Follow up if symptoms develop or worsen',
    'Maintain good respiratory hygiene',
  ]
};

const ResultDetails: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const [result, setResult] = useState(mockResult);
  const [isLoading, setIsLoading] = useState(true);
  const [showImageModal, setShowImageModal] = useState(false);
  
  useEffect(() => {
    // Simulate loading data
    const timer = setTimeout(() => {
      setIsLoading(false);
    }, 1000);
    
    return () => clearTimeout(timer);
  }, [id]);
  
  const formatDate = (date: Date) => {
    return date.toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'long',
      day: 'numeric',
    });
  };
  
  const handleChatbotRedirect = () => {
    navigate('/chatbot');
  };
  
  const getResultBadgeColor = (result: string) => {
    switch (result) {
      case 'Positive':
        return 'bg-red-100 text-red-800';
      case 'Negative':
        return 'bg-green-100 text-green-800';
      case 'Inconclusive':
        return 'bg-yellow-100 text-yellow-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };
  
  const getSeverityColor = (severity: string) => {
    switch (severity) {
      case 'None':
        return 'text-green-600';
      case 'Mild':
        return 'text-yellow-600';
      case 'Moderate':
        return 'text-orange-600';
      case 'Severe':
        return 'text-red-600';
      default:
        return 'text-gray-600';
    }
  };
  
  if (isLoading) {
    return (
      <div className="flex flex-col items-center justify-center min-h-[400px]">
        <div className="animate-spin rounded-full h-16 w-16 border-t-2 border-b-2 border-primary-600 mb-4"></div>
        <p className="text-gray-600">Loading results...</p>
      </div>
    );
  }
  
  return (
    <div className="animate-fade-in">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between mb-8 space-y-4 md:space-y-0">
        <div>
          <div className="flex items-center text-sm text-gray-500 mb-2">
            <Link to="/dashboard" className="hover:text-primary-600">Dashboard</Link>
            <ChevronRight className="h-4 w-4 mx-1" />
            <span>Results</span>
            <ChevronRight className="h-4 w-4 mx-1" />
            <span>ID: {result.xRayId}</span>
          </div>
          <h1 className="text-2xl md:text-3xl font-bold text-gray-800">
            X-Ray Analysis Results
          </h1>
        </div>
        
        <div className="flex space-x-3">
          <button className="btn btn-outline flex items-center">
            <Printer className="h-4 w-4 mr-2" />
            <span>Print</span>
          </button>
          <button className="btn btn-outline flex items-center">
            <Download className="h-4 w-4 mr-2" />
            <span>Download</span>
          </button>
          <button className="btn btn-outline flex items-center">
            <Share2 className="h-4 w-4 mr-2" />
            <span>Share</span>
          </button>
        </div>
      </div>
      
      {/* Result Summary Card */}
      <div className="card mb-8 overflow-hidden">
        <div className={`px-6 py-4 ${result.result === 'Negative' ? 'bg-green-500' : 'bg-red-500'} text-white`}>
          <div className="flex flex-col md:flex-row md:items-center justify-between">
            <div className="flex items-center">
              <div className="bg-white bg-opacity-20 p-2 rounded-full mr-4">
                <FileText className="h-6 w-6 text-white" />
              </div>
              <div>
                <h2 className="text-lg font-semibold">Analysis Result</h2>
                <p className="text-sm text-white text-opacity-90">
                  Completed on {formatDate(result.date)}
                </p>
              </div>
            </div>
            
            <div className="mt-4 md:mt-0 flex items-center">
              <span className="text-2xl font-bold mr-2">
                {result.result}
              </span>
              <span className="bg-white bg-opacity-20 px-3 py-1 rounded-full text-sm">
                {(result.confidence * 100).toFixed(0)}% confidence
              </span>
            </div>
          </div>
        </div>
        
        <div className="p-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-6">
            <div>
              <h3 className="text-lg font-semibold mb-4 text-gray-800">X-Ray Image</h3>
              <div className="relative overflow-hidden rounded-lg cursor-pointer" onClick={() => setShowImageModal(true)}>
                <img
                  src={result.imageUrl}
                  alt="X-Ray"
                  className="w-full h-64 object-cover hover:scale-105 transition-transform duration-300"
                />
                <div className="absolute inset-0 bg-black bg-opacity-40 opacity-0 hover:opacity-100 flex items-center justify-center transition-opacity duration-300">
                  <span className="text-white font-medium">Click to enlarge</span>
                </div>
              </div>
            </div>
            
            <div>
              <h3 className="text-lg font-semibold mb-4 text-gray-800">Patient Information</h3>
              <table className="w-full">
                <tbody>
                  <tr className="border-b border-gray-200">
                    <td className="py-2 text-gray-600">Patient Name:</td>
                    <td className="py-2 font-medium text-gray-800">{result.patientName}</td>
                  </tr>
                  <tr className="border-b border-gray-200">
                    <td className="py-2 text-gray-600">Age:</td>
                    <td className="py-2 font-medium text-gray-800">{result.patientAge} years</td>
                  </tr>
                  <tr className="border-b border-gray-200">
                    <td className="py-2 text-gray-600">Scan ID:</td>
                    <td className="py-2 font-medium text-gray-800">{result.xRayId}</td>
                  </tr>
                  <tr className="border-b border-gray-200">
                    <td className="py-2 text-gray-600">Date Analyzed:</td>
                    <td className="py-2 font-medium text-gray-800">{formatDate(result.date)}</td>
                  </tr>
                  <tr>
                    <td className="py-2 text-gray-600">Result:</td>
                    <td className="py-2">
                      <span className={`px-3 py-1 rounded-full text-sm font-medium ${getResultBadgeColor(result.result)}`}>
                        {result.result}
                      </span>
                    </td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>
          
          <div className="border-t border-gray-200 pt-6">
            <h3 className="text-lg font-semibold mb-3 text-gray-800">Analysis Details</h3>
            <p className="text-gray-700 mb-4">{result.details}</p>
            
            <div className="bg-gray-50 p-4 rounded-md border border-gray-200 mb-4">
              <div className="flex items-start">
                {result.result === 'Negative' ? (
                  <div className="bg-green-100 p-2 rounded-full mr-3">
                    <Check className="h-5 w-5 text-green-600" />
                  </div>
                ) : (
                  <div className="bg-red-100 p-2 rounded-full mr-3">
                    <AlertTriangle className="h-5 w-5 text-red-600" />
                  </div>
                )}
                <div>
                  <h4 className="font-medium text-gray-800">
                    {result.result === 'Negative' 
                      ? 'No signs of pneumonia detected' 
                      : 'Signs of pneumonia detected'}
                  </h4>
                  <p className="text-sm text-gray-600 mt-1">
                    {result.result === 'Negative'
                      ? 'The AI analysis did not detect patterns consistent with pneumonia in this X-ray.'
                      : 'The AI analysis detected patterns consistent with pneumonia in this X-ray.'}
                  </p>
                </div>
              </div>
            </div>
            
            <h3 className="text-lg font-semibold mb-3 text-gray-800">Detailed Findings</h3>
            <div className="overflow-x-auto mb-6">
              <table className="w-full border-collapse">
                <thead>
                  <tr className="bg-gray-50">
                    <th className="py-2 px-4 text-left border border-gray-200 text-gray-600">Lung Area</th>
                    <th className="py-2 px-4 text-left border border-gray-200 text-gray-600">Finding</th>
                    <th className="py-2 px-4 text-left border border-gray-200 text-gray-600">Severity</th>
                  </tr>
                </thead>
                <tbody>
                  {result.findings.map((finding, index) => (
                    <tr key={index} className={index % 2 === 0 ? 'bg-white' : 'bg-gray-50'}>
                      <td className="py-2 px-4 border border-gray-200">{finding.area}</td>
                      <td className="py-2 px-4 border border-gray-200">{finding.finding}</td>
                      <td className="py-2 px-4 border border-gray-200">
                        <span className={`font-medium ${getSeverityColor(finding.severity)}`}>
                          {finding.severity}
                        </span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
            
            <h3 className="text-lg font-semibold mb-3 text-gray-800">Recommendations</h3>
            <ul className="list-disc pl-5 mb-6">
              {result.recommendations.map((recommendation, index) => (
                <li key={index} className="text-gray-700 mb-1">{recommendation}</li>
              ))}
            </ul>
            
            <div className="bg-blue-50 border border-blue-200 rounded-md p-4 mb-6">
              <div className="flex">
                <div className="bg-blue-100 p-2 rounded-full mr-3">
                  <User className="h-5 w-5 text-blue-600" />
                </div>
                <div>
                  <h4 className="font-medium text-gray-800">Important Note</h4>
                  <p className="text-sm text-gray-600 mt-1">
                    This analysis is performed by an AI system and should not be considered a medical diagnosis. 
                    Always consult with a healthcare professional for proper medical advice.
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      
      {/* Actions Section */}
      <div className="mb-8 grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="card p-6 bg-gradient-to-br from-accent-500 to-accent-700 text-white">
          <div className="flex items-start justify-between mb-6">
            <div>
              <h3 className="text-xl font-semibold mb-2">Have Questions?</h3>
              <p className="text-accent-100">
                Talk to our AI assistant to learn more about your results or pneumonia in general.
              </p>
            </div>
            <div className="bg-white bg-opacity-20 p-3 rounded-lg">
              <MessageSquare className="h-6 w-6 text-white" />
            </div>
          </div>
          <button
            onClick={handleChatbotRedirect}
            className="inline-block bg-white text-accent-700 hover:bg-accent-50 font-medium py-2 px-4 rounded-md transition-colors"
          >
            Chat with AI Assistant
          </button>
        </div>
        
        <div className="card p-6 bg-gradient-to-br from-secondary-500 to-secondary-700 text-white">
          <div className="flex items-start justify-between mb-6">
            <div>
              <h3 className="text-xl font-semibold mb-2">Analyze Another X-Ray</h3>
              <p className="text-secondary-100">
                Upload another X-ray image for pneumonia detection analysis.
              </p>
            </div>
            <div className="bg-white bg-opacity-20 p-3 rounded-lg">
              <FileText className="h-6 w-6 text-white" />
            </div>
          </div>
          <Link
            to="/upload"
            className="inline-block bg-white text-secondary-700 hover:bg-secondary-50 font-medium py-2 px-4 rounded-md transition-colors"
          >
            Upload New X-Ray
          </Link>
        </div>
      </div>
      
      {/* Image Modal */}
      {showImageModal && (
        <div className="fixed inset-0 bg-black bg-opacity-75 flex items-center justify-center z-50 p-4" onClick={() => setShowImageModal(false)}>
          <div className="max-w-4xl max-h-screen overflow-auto" onClick={e => e.stopPropagation()}>
            <div className="relative">
              <button 
                className="absolute top-3 right-3 bg-black bg-opacity-50 text-white rounded-full p-1 hover:bg-opacity-70 transition-colors"
                onClick={() => setShowImageModal(false)}
              >
                <X className="h-6 w-6" />
              </button>
              <img 
                src={result.imageUrl} 
                alt="X-Ray Full View" 
                className="max-w-full max-h-[80vh] object-contain rounded-lg" 
              />
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default ResultDetails;