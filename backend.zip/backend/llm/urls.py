from django.urls import path
from .views import voice_chat, text_chat

urlpatterns = [
    path("chat/", voice_chat),
    path("text_chat/", text_chat),
]
