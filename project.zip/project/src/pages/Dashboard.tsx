import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { Upload, FileText, Calendar, BarChart, Clock, ExternalLink } from 'lucide-react';

// Mock data for demonstration
const mockXRays = [
  {
    id: '1',
    imageUrl: 'https://images.pexels.com/photos/4226119/pexels-photo-4226119.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1',
    result: 'Negative',
    confidence: 0.92,
  },
  {
    id: '2',
    imageUrl: 'https://images.pexels.com/photos/4226264/pexels-photo-4226264.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1',
    date: new Date(2023, 9, 5),
    result: 'Positive',
    confidence: 0.88,
  },
  {
    id: '3',
    imageUrl: 'https://images.pexels.com/photos/5726837/pexels-photo-5726837.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1',
    date: new Date(2023, 8, 28),
    result: 'Negative',
    confidence: 0.95,
  },
];

const Dashboard: React.FC = () => {
  const { user, isAuthenticated } = useAuth();
  const [recentXRays, setRecentXRays] = useState<{ result: string; user?: string }[]>([]);
  
  // Filter to only current user's X-rays if user is present
  const userXRays = user ? recentXRays.filter(x => x.user === user.username) : recentXRays;
  
  useEffect(() => {
    fetch('/api/xrays/')
      .then(res => res.json())
      .then(data => setRecentXRays(data))
      .catch(() => setRecentXRays([]));
  }, []);
  
  // Get current date for greeting message
  const currentHour = new Date().getHours();
  let greeting;
  
  if (currentHour < 12) {
    greeting = 'Good morning';
  } else if (currentHour < 18) {
    greeting = 'Good afternoon';
  } else {
    greeting = 'Good evening';
  }
  
  // Format date as string
  const formatDate = (date: Date) => {
    return date.toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
    });
  };
  
  // Get result badge color
  const getResultBadgeColor = (result: string) => {
    switch (result) {
      case 'Positive':
        return 'bg-red-100 text-red-800';
      case 'Negative':
        return 'bg-green-100 text-green-800';
      case 'Inconclusive':
        return 'bg-yellow-100 text-yellow-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };
  
  return (
    <div className="animate-fade-in">
      <div className="mb-8">
        <h1 className="text-2xl md:text-3xl font-bold text-gray-800 mb-2">
          {greeting}{user ? `, ${user.name}` : ''}
        </h1>
        <p className="text-gray-600">
          Welcome to your MedScanX dashboard. Here you can manage your X-rays and view results.
        </p>
      </div>
      
      {/* Action Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-10">
        <div className="card p-6 bg-gradient-to-br from-primary-500 to-primary-700 text-white">
          <div className="flex items-start justify-between mb-4">
            <div>
              <h3 className="text-xl font-semibold mb-2">Upload New X-Ray</h3>
              <p className="text-primary-100">
                Upload an X-ray image for AI-powered pneumonia detection
              </p>
            </div>
            <div className="bg-white bg-opacity-20 p-3 rounded-lg">
              <Upload className="h-6 w-6 text-white" />
            </div>
          </div>
          <Link
            to="/upload"
            className="inline-block bg-white text-primary-700 hover:bg-primary-50 font-medium py-2 px-4 rounded-md transition-colors mt-2"
          >
            Upload Now
          </Link>
        </div>
        
        <div className="card p-6 bg-gradient-to-br from-secondary-500 to-secondary-700 text-white">
          <div className="flex items-start justify-between mb-4">
            <div>
              <h3 className="text-xl font-semibold mb-2">View All Results</h3>
              <p className="text-secondary-100">
                Access your complete history of X-ray analyses and results
              </p>
            </div>
            <div className="bg-white bg-opacity-20 p-3 rounded-lg">
              <FileText className="h-6 w-6 text-white" />
            </div>
          </div>
          <Link
            to="/results"
            className="inline-block bg-white text-secondary-700 hover:bg-secondary-50 font-medium py-2 px-4 rounded-md transition-colors mt-2"
          >
            View History
          </Link>
        </div>
      </div>
      
      {/* Stats Overview */}
      <div>
        <h2 className="text-xl font-bold text-gray-800 mb-6">Overview</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-6">
          <div className="card p-6">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-gray-500 text-sm font-medium">Total X-Rays</h3>
              <div className="bg-primary-100 p-2 rounded-md">
                <FileText className="h-5 w-5 text-primary-600" />
              </div>
            </div>
            <p className="text-3xl font-bold text-gray-800">{userXRays.length}</p>
          </div>
          


          {/* Bacterial Pneumonia Card */}
          <div className="card p-6">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-gray-500 text-sm font-medium">Bacterial = Pneumonia</h3>
              <div className="bg-blue-100 p-2 rounded-md">
                <BarChart className="h-5 w-5 text-blue-600" />
              </div>
            </div>
            <p className="text-3xl font-bold text-gray-800">
              {userXRays.filter(x => x.result === 'Bacterial Pneumonia').length}
            </p>
          </div>

          {/* COVID-19 Card */}
          <div className="card p-6">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-gray-500 text-sm font-medium">COVID-19</h3>
              <div className="bg-yellow-100 p-2 rounded-md">
                <BarChart className="h-5 w-5 text-yellow-600" />
              </div>
            </div>
            <p className="text-3xl font-bold text-gray-800">
              {userXRays.filter(x => x.result === 'COVID-19').length}
            </p>
          </div>

          {/* Viral Pneumonia Card */}
          <div className="card p-6">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-gray-500 text-sm font-medium">Viral = Pneumonia</h3>
              <div className="bg-purple-100 p-2 rounded-md">
                <BarChart className="h-5 w-5 text-purple-600" />
              </div>
            </div>
            <p className="text-3xl font-bold text-gray-800">
              {userXRays.filter(x => x.result === 'Viral Pneumonia').length}
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;