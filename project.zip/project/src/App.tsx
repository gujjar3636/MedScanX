// import React from 'react';
// import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
// import { AuthProvider, useAuth } from './context/AuthContext';


// // Pages
// import Home from './pages/Home';
// import Login from './pages/Login';
// import Signup from './pages/Signup';
// import Dashboard from './pages/Dashboard';
// import UploadXRay from './pages/UploadXRay';
// import Results from './pages/Results';
// import Chatbot from './pages/Chatbot';
// import NotFound from './pages/NotFound';


// // Layout components
// import MainLayout from './components/layout/MainLayout';

// // Protected route component
// const ProtectedRoute: React.FC<{ children: React.ReactElement }> = ({ children }) => {
//   const { isAuthenticated } = useAuth();
  
//   if (!isAuthenticated) {
//     return <Navigate to="/login" replace />;
//   }
  
//   return children;
// };

// function AppRoutes() {
//   return (
//     <Router>
//       <Routes>
//         <Route path="/" element={<MainLayout><Home /></MainLayout>} />
//         <Route path="/login" element={<Login />} />
//         <Route path="/signup" element={<Signup />} />
        
//         {/* Protected routes */}
//         <Route 
//           path="/dashboard" 
//           element={
//             <ProtectedRoute>
//               <MainLayout><Dashboard /></MainLayout>
//             </ProtectedRoute>
//           } 
//         />
//         <Route 
//           path="/upload" 
//           element={
//             <ProtectedRoute>
//               <MainLayout><UploadXRay /></MainLayout>
//             </ProtectedRoute>
//           } 
//         />
//         <Route 
//           path="/results/:id" 
//           element={
//             <ProtectedRoute>
//               <MainLayout><Results /></MainLayout>
//             </ProtectedRoute>
//           } 
//         />
//         <Route 
//           path="/chatbot" 
//           element={
//             <ProtectedRoute>
//               <MainLayout><Chatbot /></MainLayout>
//             </ProtectedRoute>
//           } 
//         />
        
//         {/* 404 route */}
//         <Route path="*" element={<NotFound />} />
//       </Routes>
//     </Router>
//   );
// }

// function App() {
//   return (
//     <AuthProvider>
//       <AppRoutes />
//     </AuthProvider>
//   );
// }

// export default App;




import React from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { AuthProvider, useAuth } from './context/AuthContext';
import { ToastProvider } from './components/ToastContainer';

// Pages
import Home from './pages/Home';
import Login from './pages/Login';
import Signup from './pages/Signup';
import Dashboard from './pages/Dashboard';
import UploadXRay from './pages/UploadXRay';
import Results from './pages/Results';
import Chatbot from './pages/Chatbot';
import NotFound from './pages/NotFound';
import AboutUs from './pages/aboutus';
import ContactUs from './pages/contactus';

// Layout
import MainLayout from './components/layout/MainLayout';

// Protected route component
const ProtectedRoute: React.FC<{ children: React.ReactElement }> = ({ children }) => {
  const { isAuthenticated } = useAuth();
  if (!isAuthenticated) {
    return <Navigate to="/login" replace />;
  }
  return children;
};

function AppRoutes() {
  return (
    <Router>
      <Routes>
        <Route path="/" element={<MainLayout><Home /></MainLayout>} />
        <Route path="/login" element={<Login />} />
        <Route path="/signup" element={<Signup />} />
        <Route path="/about" element={<MainLayout><AboutUs /></MainLayout>} />
        <Route path="/contact" element={<MainLayout><ContactUs /></MainLayout>} />

        {/* Protected routes */}
        <Route path="/dashboard" element={
          <ProtectedRoute>
            <MainLayout><Dashboard /></MainLayout>
          </ProtectedRoute>
        } />
        <Route path="/upload" element={
          <ProtectedRoute>
            <MainLayout><UploadXRay /></MainLayout>
          </ProtectedRoute>
        } />
        <Route path="/results/:id" element={
          <ProtectedRoute>
            <MainLayout><Results /></MainLayout>
          </ProtectedRoute>
        } />
        <Route path="/chatbot" element={
          <ProtectedRoute>
            <MainLayout><Chatbot /></MainLayout>
          </ProtectedRoute>
        } />

        {/* 404 */}
        <Route path="*" element={<NotFound />} />
      </Routes>
    </Router>
  );
}

function App() {
  return (
    <AuthProvider>
      <ToastProvider>
        <AppRoutes />
      </ToastProvider>
    </AuthProvider>
  );
}

export default App;
