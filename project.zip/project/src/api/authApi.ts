const API_BASE = "http://127.0.0.1:8000/user"; // Django backend URL

export async function signup(username: string, password: string) {
    const response = await fetch(`${API_BASE}/signup/`, {
        method: 'POST',
        credentials: 'include', // VERY IMPORTANT for cookies
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify({ username, password }),
    });
    return response.json();
}

export async function login(username: string, password: string) {
    const response = await fetch(`${API_BASE}/login/`, {
        method: 'POST',
        credentials: 'include',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify({ username, password }),
    });
    return response.json();
}

export async function logout() {
    const response = await fetch(`${API_BASE}/logout/`, {
        method: 'POST',
        credentials: 'include',
    });
    return response.json();
}
