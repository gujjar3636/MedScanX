from django.contrib import admin
from django.urls import path ,include
from core.views import detect, contact_us, xray_results_api
from django.conf import settings
from django.conf.urls.static import static 
from .import views
urlpatterns = [
    path('', views.detect ,name="detect"),
    path('contact/', views.contact_us, name='contact_us'),
    path('api/xrays/', xray_results_api, name='xray_results_api'),
] 