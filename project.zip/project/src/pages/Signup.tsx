import React, { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { useToast } from '../components/ToastContainer';
import { SignupCredentials } from '../types';
import { Stethoscope, AlertCircle, Check, X } from 'lucide-react';

const Signup: React.FC = () => {
  const [credentials, setCredentials] = useState<SignupCredentials>({
    username: '',
    email: '',
    password: '',
    confirmPassword: '',
  });

  const [formErrors, setFormErrors] = useState<Record<string, string>>({});
  const [passwordStrength, setPasswordStrength] = useState({
    score: 0,
    hasMinLength: false,
    hasUppercase: false,
    hasLowercase: false,
    hasNumber: false,
    hasSpecialChar: false,
  });

  const { signup, error, isLoading, clearError } = useAuth();
  const { showToast } = useToast();
  const navigate = useNavigate();

  useEffect(() => {
    clearError();
  }, [clearError]);

  useEffect(() => {
    const { password } = credentials;
    const checks = {
      hasMinLength: password.length >= 8,
      hasUppercase: /[A-Z]/.test(password),
      hasLowercase: /[a-z]/.test(password),
      hasNumber: /[0-9]/.test(password),
      hasSpecialChar: /[^A-Za-z0-9]/.test(password),
    };
    const score = Object.values(checks).filter(Boolean).length;
    setPasswordStrength({ score, ...checks });
  }, [credentials.password]);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setCredentials(prev => ({
      ...prev,
      [name]: value,
    }));

    if (formErrors[name]) {
      setFormErrors(prev => ({ ...prev, [name]: '' }));
    }
  };

  const validateForm = () => {
    const errors: Record<string, string> = {};
    let valid = true;

    if (!credentials.username.trim()) {
      errors.username = 'Username is required';
      valid = false;
    }
    if (!credentials.email.trim()) {
      errors.email = 'Email is required';
      valid = false;
    } else if (!/\S+@\S+\.\S+/.test(credentials.email)) {
      errors.email = 'Email is invalid';
      valid = false;
    }
    if (!credentials.password) {
      errors.password = 'Password is required';
      valid = false;
    } else if (passwordStrength.score < 3) {
      errors.password = 'Password is too weak';
      valid = false;
    }
    if (credentials.password !== credentials.confirmPassword) {
      errors.confirmPassword = 'Passwords do not match';
      valid = false;
    }

    setFormErrors(errors);
    return valid;
  };

  const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    if (validateForm()) {
      const { username, email, password } = credentials;
      const result = await signup({ username, email, password, confirmPassword: credentials.confirmPassword });
      
      if (result.success) {
        showToast({
          type: 'success',
          title: 'Account Created Successfully!',
          message: 'Your account has been created. Please log in to continue.',
          duration: 4000
        });
        navigate('/login');
      } else {
        // Check if it's a user already exists error
        if (result.error && (result.error.toLowerCase().includes('already exists') || result.error.toLowerCase().includes('email already exists') || result.error.toLowerCase().includes('username already exists'))) {
          showToast({
            type: 'error',
            title: 'User Already Exists',
            message: result.error,
            duration: 5000
          });
        } else {
          showToast({
            type: 'error',
            title: 'Signup Failed',
            message: result.error || 'Something went wrong. Please try again.',
            duration: 5000
          });
        }
      }
    }
  };

  const getPasswordStrengthColor = () => {
    const { score } = passwordStrength;
    if (score <= 1) return 'bg-red-500';
    if (score <= 2) return 'bg-orange-500';
    if (score <= 3) return 'bg-yellow-500';
    if (score <= 4) return 'bg-lime-500';
    return 'bg-green-500';
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-gray-100 to-gray-200 py-12 px-4 sm:px-6 lg:px-8">
      <div className="max-w-md w-full bg-white rounded-xl shadow-lg overflow-hidden">
        <div className="bg-primary-600 p-6 text-center">
          <Link to="/" className="inline-block">
            <Stethoscope className="h-12 w-12 text-white mx-auto" />
          </Link>
          <h2 className="mt-4 text-2xl font-bold text-white">Create your account</h2>
          <p className="mt-2 text-primary-100">Join MedScanX for AI-powered pneumonia detection</p>
        </div>

        <div className="p-6 sm:p-8">
          {error && (
            <div className="mb-4 bg-red-50 text-red-700 p-3 rounded-md flex items-center">
              <AlertCircle className="h-5 w-5 mr-2 flex-shrink-0" />
              <p>{error}</p>
            </div>
          )}

          <form className="space-y-5" onSubmit={handleSubmit} noValidate>
            {/* Username */}
            <div>
              <label htmlFor="username" className="block text-sm font-medium text-gray-700 mb-1">
                Username
              </label>
              <input
                id="username"
                name="username"
                type="text"
                autoComplete="username"
                required
                className={`w-full px-4 py-2 border rounded-md focus:ring-2 ${
                  formErrors.username ? 'border-red-500 focus:ring-red-400' : 'border-gray-300 focus:ring-primary-500'
                }`}
                value={credentials.username}
                onChange={handleChange}
              />
              {formErrors.username && <p className="mt-1 text-sm text-red-600">{formErrors.username}</p>}
            </div>

            {/* Email */}
            <div>
              <label htmlFor="email" className="block text-sm font-medium text-gray-700 mb-1">
                Email Address
              </label>
              <input
                id="email"
                name="email"
                type="email"
                autoComplete="email"
                required
                className={`w-full px-4 py-2 border rounded-md focus:ring-2 ${
                  formErrors.email ? 'border-red-500 focus:ring-red-400' : 'border-gray-300 focus:ring-primary-500'
                }`}
                value={credentials.email}
                onChange={handleChange}
              />
              {formErrors.email && <p className="mt-1 text-sm text-red-600">{formErrors.email}</p>}
            </div>

            {/* Password */}
            <div>
              <label htmlFor="password" className="block text-sm font-medium text-gray-700 mb-1">
                Password
              </label>
              <input
                id="password"
                name="password"
                type="password"
                autoComplete="new-password"
                required
                className={`w-full px-4 py-2 border rounded-md focus:ring-2 ${
                  formErrors.password ? 'border-red-500 focus:ring-red-400' : 'border-gray-300 focus:ring-primary-500'
                }`}
                value={credentials.password}
                onChange={handleChange}
              />
              {formErrors.password && <p className="mt-1 text-sm text-red-600">{formErrors.password}</p>}

              {/* Password strength */}
              {credentials.password && (
                <div className="mt-2">
                  <div className="h-2 w-full bg-gray-200 rounded-full overflow-hidden">
                    <div
                      className={`h-full ${getPasswordStrengthColor()}`}
                      style={{ width: `${(passwordStrength.score / 5) * 100}%` }}
                    />
                  </div>

                  <div className="mt-3 grid grid-cols-2 gap-2 text-sm">
                    {[
                      { label: 'At least 8 characters', check: passwordStrength.hasMinLength },
                      { label: 'Uppercase letter', check: passwordStrength.hasUppercase },
                      { label: 'Lowercase letter', check: passwordStrength.hasLowercase },
                      { label: 'Number', check: passwordStrength.hasNumber },
                      { label: 'Special character', check: passwordStrength.hasSpecialChar },
                    ].map(({ label, check }) => (
                      <div key={label} className="flex items-center text-gray-600">
                        {check ? (
                          <Check className="h-4 w-4 text-green-500 mr-1" />
                        ) : (
                          <X className="h-4 w-4 text-red-500 mr-1" />
                        )}
                        <span>{label}</span>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>

            {/* Confirm Password */}
            <div>
              <label htmlFor="confirmPassword" className="block text-sm font-medium text-gray-700 mb-1">
                Confirm Password
              </label>
              <input
                id="confirmPassword"
                name="confirmPassword"
                type="password"
                autoComplete="new-password"
                required
                className={`w-full px-4 py-2 border rounded-md focus:ring-2 ${
                  formErrors.confirmPassword ? 'border-red-500 focus:ring-red-400' : 'border-gray-300 focus:ring-primary-500'
                }`}
                value={credentials.confirmPassword}
                onChange={handleChange}
              />
              {formErrors.confirmPassword && <p className="mt-1 text-sm text-red-600">{formErrors.confirmPassword}</p>}
            </div>

            {/* Terms */}
            <div className="flex items-center">
              <input
                id="terms"
                name="terms"
                type="checkbox"
                required
                className="h-4 w-4 text-primary-600 focus:ring-primary-500 border-gray-300 rounded"
              />
              <label htmlFor="terms" className="ml-2 block text-sm text-gray-700">
                I agree to the{' '}
                <Link to="/terms" className="text-primary-600 hover:text-primary-700">
                  Terms of Service
                </Link>{' '}
                and{' '}
                <Link to="/privacy" className="text-primary-600 hover:text-primary-700">
                  Privacy Policy
                </Link>
              </label>
            </div>

            {/* Submit */}
            <div>
              <button
                type="submit"
                className="w-full flex justify-center py-3 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-primary-600 hover:bg-primary-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary-500 transition-colors disabled:opacity-50"
                disabled={isLoading}
              >
                {isLoading ? 'Creating account...' : 'Create Account'}
              </button>
            </div>
          </form>

          <div className="mt-6 text-center">
            <p className="text-sm text-gray-600">
              Already have an account?{' '}
              <Link to="/login" className="font-medium text-primary-600 hover:text-primary-700">
                Log in
              </Link>
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Signup;
