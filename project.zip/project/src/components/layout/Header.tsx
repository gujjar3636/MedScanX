import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Menu, X, LogOut, ChevronDown, User, Stethoscope } from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import { useToast } from '../ToastContainer';

const Header: React.FC = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [isProfileDropdownOpen, setIsProfileDropdownOpen] = useState(false);
  const { user, isAuthenticated, logout } = useAuth();
  const { showToast } = useToast();
  const navigate = useNavigate();

  const toggleMenu = () => setIsMenuOpen(!isMenuOpen);
  const toggleProfileDropdown = () => setIsProfileDropdownOpen(!isProfileDropdownOpen);

  const handleLogout = async () => {
    await logout();
    showToast({
      type: 'success',
      title: 'Logged Out Successfully',
      message: 'You have been successfully logged out.',
      duration: 3000
    });
    navigate('/login');
  };

  return (
    <header className="bg-white shadow-md sticky top-0 z-50">
      <div className="container mx-auto px-4 py-3 md:py-4">
        <div className="flex items-center justify-between">
          {/* Logo */}
          <Link to="/" className="flex items-center space-x-2">
            <Stethoscope className="h-8 w-8 text-primary-600" />
            <span className="text-xl font-bold bg-gradient-to-r from-primary-600 to-secondary-500 bg-clip-text text-transparent">
              MedScanX
            </span>
          </Link>

          {/* Desktop Navigation */}
          <nav className="hidden md:flex items-center space-x-6">
            <Link to="/" className="text-gray-700 hover:text-primary-600 font-medium transition-colors">
              Home
            </Link>
            <Link to="/about" className="text-gray-700 hover:text-primary-600 font-medium transition-colors">
              About Us
            </Link>
            <Link to="/contact" className="text-gray-700 hover:text-primary-600 font-medium transition-colors">
              Contact Us
            </Link>
            <a href="http://localhost:8000/admin/" target="_blank" rel="noopener noreferrer" className="text-gray-700 hover:text-primary-600 font-medium transition-colors">
              Admin
            </a>
            {isAuthenticated && (
              <>
                <Link to="/dashboard" className="text-gray-700 hover:text-primary-600 font-medium transition-colors">
                  Dashboard
                </Link>
              </>
            )}
          </nav>

          {/* Auth / Profile */}
          <div className="hidden md:flex items-center space-x-4">
            {isAuthenticated ? (
              <div className="relative">
                <button onClick={toggleProfileDropdown} className="flex items-center space-x-2 bg-gray-100 hover:bg-gray-200 rounded-full py-2 px-4 transition-colors">
                  <span className="font-medium">{user?.name}</span>
                  <ChevronDown size={16} />
                </button>
                {isProfileDropdownOpen && (
                  <div className="absolute right-0 mt-2 w-48 bg-white rounded-md shadow-lg py-1 z-10 animate-fade-in">
                    <Link to="/dashboard" className="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100 flex items-center" onClick={() => setIsProfileDropdownOpen(false)}>
                      <User size={16} className="mr-2" />
                      My Dashboard
                    </Link>
                    <button onClick={handleLogout} className="block w-full text-left px-4 py-2 text-sm text-red-500 hover:bg-gray-100 flex items-center">
                      <LogOut size={16} className="mr-2" />
                      Sign Out
                    </button>
                  </div>
                )}
              </div>
            ) : (
              <>
                <Link to="/login" className="text-primary-600 hover:text-primary-700 font-medium">Log In</Link>
                <Link to="/signup" className="bg-primary-600 hover:bg-primary-700 text-white font-medium py-2 px-4 rounded-md transition-colors">Sign Up</Link>
              </>
            )}
          </div>

          {/* Mobile Menu Toggle */}
          <button className="md:hidden" onClick={toggleMenu}>
            {isMenuOpen ? <X className="h-6 w-6 text-gray-700" /> : <Menu className="h-6 w-6 text-gray-700" />}
          </button>
        </div>

        {/* Mobile Menu */}
        {isMenuOpen && (
          <div className="md:hidden mt-4 py-4 border-t border-gray-200 animate-fade-in">
            <nav className="flex flex-col space-y-4">
              <Link to="/" className="text-gray-700 hover:text-primary-600 font-medium transition-colors" onClick={toggleMenu}>
                Home
              </Link>
              <Link to="/about" className="text-gray-700 hover:text-primary-600 font-medium transition-colors" onClick={toggleMenu}>
                About Us
              </Link>
              <Link to="/contact" className="text-gray-700 hover:text-primary-600 font-medium transition-colors" onClick={toggleMenu}>
                Contact Us
              </Link>
              <a href="http://localhost:8000/admin/" target="_blank" rel="noopener noreferrer" className="text-gray-700 hover:text-primary-600 font-medium transition-colors">
                Admin
              </a>
              {isAuthenticated && (
                <>
                  <Link to="/dashboard" className="text-gray-700 hover:text-primary-600 font-medium transition-colors" onClick={toggleMenu}>
                    Dashboard
                  </Link>
                </>
              )}
              {isAuthenticated ? (
                <button onClick={() => { handleLogout(); toggleMenu(); }} className="text-red-500 hover:text-red-600 font-medium flex items-center">
                  <LogOut size={16} className="mr-2" />
                  Sign Out
                </button>
              ) : (
                <div className="flex flex-col space-y-2 pt-2 border-t border-gray-200">
                  <Link to="/login" className="text-primary-600 hover:text-primary-700 font-medium" onClick={toggleMenu}>
                    Log In
                  </Link>
                  <Link to="/signup" className="bg-primary-600 hover:bg-primary-700 text-white font-medium py-2 px-4 rounded-md transition-colors inline-block text-center" onClick={toggleMenu}>
                    Sign Up
                  </Link>
                </div>
              )}
            </nav>
          </div>
        )}
      </div>
    </header>
  );
};

export default Header;
