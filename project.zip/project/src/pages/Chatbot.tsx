import React, { useState, useEffect, useRef } from 'react';
import { Send, User, Bot, ArrowLeft, Mic, Square } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

const Chatbot: React.FC = () => {
  const [messages, setMessages] = useState<any[]>([{
    id: '1',
    userId: 'bot',
    type: 'bot',
    content: "Hello! I'm your voice-enabled assistant. Tap the mic and ask me something!",
    timestamp: new Date()
  }]);
  const [isTyping, setIsTyping] = useState(false);
  const [recording, setRecording] = useState(false);
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const audioChunksRef = useRef<Blob[]>([]);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const navigate = useNavigate();
  const [language, setLanguage] = useState("en"); // "en" for English, "ur" for Urdu
  const [mode, setMode] = useState<'talk' | 'prompt'>('talk'); // Add mode state
  const [promptInput, setPromptInput] = useState(""); // For prompt mode input

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  const formatTimestamp = (timestamp: Date) => timestamp.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });

  const startRecording = async () => {
    const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
    const mediaRecorder = new MediaRecorder(stream, { mimeType: 'audio/webm' });

    audioChunksRef.current = [];

    mediaRecorder.ondataavailable = (event) => {
      if (event.data.size > 0) audioChunksRef.current.push(event.data);
    };

    mediaRecorder.onstop = async () => {
      const audioBlob = new Blob(audioChunksRef.current, { type: 'audio/webm' });
      sendAudioToBackend(audioBlob);
    };

    mediaRecorderRef.current = mediaRecorder;
    mediaRecorder.start();
    setRecording(true);
  };

  const stopRecording = () => {
    mediaRecorderRef.current?.stop();
    setRecording(false);
  };

  const sendAudioToBackend = async (audioBlob: Blob) => {
    const formData = new FormData();
    formData.append('audio', audioBlob, 'recording.webm');
    formData.append('language', language); // Add language to form data

    const userMessage = {
      id: Date.now().toString(),
      userId: 'user',
      type: 'user',
      content: '[Voice message]',
      timestamp: new Date()
    };
    setMessages(prev => [...prev, userMessage]);
    setIsTyping(true);

    try {
      const response = await fetch('http://localhost:8000/llm/chat/', {
        method: 'POST',
        body: formData
      });

      if (!response.ok) throw new Error('Audio upload failed');

      const audioData = await response.blob();
      const audioURL = URL.createObjectURL(audioData);
      const audio = new Audio(audioURL);

      const botMessage = {
        id: (Date.now() + 1).toString(),
        userId: 'bot',
        type: 'bot',
        content: '[Playing response...]',
        timestamp: new Date()
      };

      setMessages(prev => [...prev, botMessage]);
      setIsTyping(false);
      audio.play();
    } catch (err) {
      console.error('Error sending audio:', err);
      setIsTyping(false);
    }
  };

  // New: Send text prompt to backend
  const sendPromptToBackend = async () => {
    if (!promptInput.trim()) return;
    const userMessage = {
      id: Date.now().toString(),
      userId: 'user',
      type: 'user',
      content: promptInput,
      timestamp: new Date()
    };
    setMessages(prev => [...prev, userMessage]);
    setIsTyping(true);
    try {
      const response = await fetch('http://localhost:8000/llm/text_chat/', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ question: promptInput, language })
      });
      if (!response.ok) throw new Error('Prompt failed');
      const data = await response.json();
      const botMessage = {
        id: (Date.now() + 1).toString(),
        userId: 'bot',
        type: 'bot',
        content: data.answer,
        timestamp: new Date()
      };
      setMessages(prev => [...prev, botMessage]);
    } catch (err) {
      setMessages(prev => [...prev, {
        id: (Date.now() + 2).toString(),
        userId: 'bot',
        type: 'bot',
        content: 'Error getting response.',
        timestamp: new Date()
      }]);
    }
    setIsTyping(false);
    setPromptInput("");
  };

  return (
    <div className="flex flex-col h-[calc(100vh-230px)] min-h-[500px] animate-fade-in">
      <div className="mb-4 flex items-center justify-between">
        <div className="flex items-center">
          <button onClick={() => navigate(-1)} className="mr-4 p-2 rounded-full text-gray-600 hover:bg-gray-100">
            <ArrowLeft className="h-5 w-5" />
          </button>
          <div>
            <h1 className="text-2xl font-bold text-gray-800">Voice AI Assistant</h1>
            <p className="text-gray-600">Tap the mic and ask anything!</p>
          </div>
        </div>
        <div className="flex items-center bg-green-100 px-3 py-1 rounded-full">
          <span className="h-2 w-2 bg-green-500 rounded-full mr-2"></span>
          <span className="text-sm font-medium text-green-800">Online</span>
        </div>
      </div>

      {/* Language and Mode Selector */}
      <div className="flex justify-end mb-2 space-x-2">
        <select
          value={mode}
          onChange={e => setMode(e.target.value as 'talk' | 'prompt')}
          className="border rounded px-2 py-1 text-sm"
        >
          <option value="talk">Talk</option>
          <option value="prompt">Prompt</option>
        </select>
        <select
          value={language}
          onChange={e => setLanguage(e.target.value)}
          className="border rounded px-2 py-1 text-sm"
        >
          <option value="en">English</option>
          <option value="ur">Urdu</option>
        </select>
      </div>

      <div className="flex-grow card p-4 overflow-hidden flex flex-col bg-gray-50">
        <div className="flex-grow overflow-y-auto p-2">
          {messages.map(msg => (
            <div key={msg.id} className={`mb-4 flex ${msg.type === 'user' ? 'justify-end' : 'justify-start'}`}>
              <div className={`max-w-[80%] rounded-lg p-3 ${msg.type === 'user' ? 'bg-blue-600 text-white rounded-tr-none' : 'bg-white border border-gray-200 rounded-tl-none'}`}>
                <div className="flex items-center mb-1">
                  <div className={`p-1 rounded-full mr-2 ${msg.type === 'user' ? 'bg-white bg-opacity-20' : 'bg-blue-100'}`}>
                    {msg.type === 'user' ? <User className="h-3 w-3 text-white" /> : <Bot className="h-3 w-3 text-blue-600" />}
                  </div>
                  <span className={`text-xs ${msg.type === 'user' ? 'text-white text-opacity-80' : 'text-gray-500'}`}>
                    {msg.type === 'user' ? 'You' : 'AI Assistant'} • {formatTimestamp(msg.timestamp)}
                  </span>
                </div>
                <p>{msg.content}</p>
              </div>
            </div>
          ))}
          {isTyping && (
            <div className="mb-4 flex justify-start">
              <div className="bg-white border border-gray-200 rounded-lg rounded-tl-none p-3">
                <div className="flex items-center mb-1">
                  <div className="p-1 rounded-full mr-2 bg-blue-100">
                    <Bot className="h-3 w-3 text-blue-600" />
                  </div>
                  <span className="text-xs text-gray-500">AI Assistant is typing...</span>
                </div>
                <div className="flex space-x-1">
                  <div className="h-2 w-2 bg-gray-300 rounded-full animate-bounce"></div>
                  <div className="h-2 w-2 bg-gray-300 rounded-full animate-bounce delay-200"></div>
                  <div className="h-2 w-2 bg-gray-300 rounded-full animate-bounce delay-400"></div>
                </div>
              </div>
            </div>
          )}
          <div ref={messagesEndRef} />
        </div>

        <div className="pt-3 border-t border-gray-200">
          {mode === 'talk' ? (
            <>
              <div className="flex justify-center">
                <button
                  onClick={recording ? stopRecording : startRecording}
                  className={`p-4 rounded-full shadow-lg ${recording ? 'bg-red-500' : 'bg-blue-600'} text-white`}
                >
                  {recording ? <Square className="h-5 w-5" /> : <Mic className="h-5 w-5" />}
                </button>
              </div>
              <p className="text-xs text-gray-500 mt-2 text-center">
                Speak your question. The AI will reply in voice.
              </p>
            </>
          ) : (
            <form
              className="flex items-center space-x-2"
              onSubmit={e => { e.preventDefault(); sendPromptToBackend(); }}
            >
              <input
                type="text"
                value={promptInput}
                onChange={e => setPromptInput(e.target.value)}
                className="flex-grow border rounded px-3 py-2"
                placeholder="Type your question..."
                disabled={isTyping}
              />
              <button
                type="submit"
                className="p-2 rounded-full bg-blue-600 text-white"
                disabled={isTyping || !promptInput.trim()}
              >
                <Send className="h-5 w-5" />
              </button>
            </form>
          )}
        </div>
      </div>
    </div>
  );
};

export default Chatbot;

