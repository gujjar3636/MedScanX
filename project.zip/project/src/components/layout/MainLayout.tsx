import React, { ReactNode } from 'react';
import { Link } from 'react-router-dom';
import Header from './Header';
import Footer from './Footer';
import { useAuth } from '../../context/AuthContext';
import { MessageSquare } from 'lucide-react';

interface MainLayoutProps {
  children: ReactNode;
}

const MainLayout: React.FC<MainLayoutProps> = ({ children }) => {
  const { isAuthenticated } = useAuth();

  return (
    <div className="flex flex-col min-h-screen bg-gray-50">
      <Header />
      
      <main className="flex-grow container mx-auto px-4 py-8 md:px-6">
        {children}
      </main>
      
      {isAuthenticated && (
        <Link
          to="/chatbot"
          className="fixed bottom-6 right-6 bg-accent-600 hover:bg-accent-700 text-white p-4 rounded-full shadow-lg transition-all hover:scale-110 z-50 group"
          title="Chat with AI Assistant"
        >
          <MessageSquare className="h-6 w-6" />
          <span className="absolute right-full mr-3 bg-gray-900 text-white px-3 py-1 rounded text-sm whitespace-nowrap opacity-0 group-hover:opacity-100 transition-opacity">
            Chat with AI
          </span>
        </Link>
      )}
      
      <Footer />
    </div>
  );
};

export default MainLayout;