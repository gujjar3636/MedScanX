import { useState } from "react";
import { useAuth } from '../context/AuthContext';
import Spinner from '../components/Spinner';

export default function UploadXRay() {
  const { user } = useAuth();
  const [image, setImage] = useState<File | null>(null);
  const [previewUrl, setPreviewUrl] = useState<string | null>(null);
  const [result, setResult] = useState<string | null>(null);
  const [detectedImageUrl, setDetectedImageUrl] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);

  const handleFileChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    // Basic validation
    const validTypes = ['image/jpeg', 'image/jpg', 'image/png', 'image/gif'];
    if (!validTypes.includes(file.type)) {
      setError("Please select a valid image file (JPEG, PNG, or GIF)");
      return;
    }

    if (file.size > 10 * 1024 * 1024) { // 10MB limit
      setError("File size must be less than 10MB");
      return;
    }

    setImage(file);
    setPreviewUrl(URL.createObjectURL(file));
    setError(null);
  };

  const handleUpload = async () => {
    if (!image) return alert("Please select an image");

    setIsLoading(true);
    setError(null);

    const formData = new FormData();
    formData.append("image", image);
    if (user && user.username) {
      formData.append("username", user.username);
    }

    try {
      const res = await fetch("http://localhost:8000/detect/", {
        method: "POST",
        body: formData,
      });

      const data = await res.json();
      setResult(data.result);
      setDetectedImageUrl(`http://localhost:8000${data.image_url}`);
    } catch (error) {
      setError("Something went wrong with the detection.");
      console.error(error);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="p-6 max-w-xl mx-auto">
      <h2 className="text-2xl font-semibold mb-4">Upload Chest X-Ray</h2>

      <div className="mb-6">
        <label className="block text-sm font-medium text-gray-700 mb-2">
          Select X-Ray Image
        </label>
        <input
          type="file"
          accept="image/*"
          onChange={handleFileChange}
          className="block w-full text-sm text-gray-500 file:mr-4 file:py-2 file:px-4 file:rounded-full file:border-0 file:text-sm file:font-semibold file:bg-blue-50 file:text-blue-700 hover:file:bg-blue-100"
        />
      </div>

      {error && (
        <div className="mb-4 p-3 bg-red-100 border border-red-400 text-red-700 rounded">
          {error}
        </div>
      )}

      {previewUrl && (
        <div className="mb-4">
          <img src={previewUrl} alt="Preview" className="rounded shadow max-w-full h-auto" />
        </div>
      )}

      <button
        onClick={handleUpload}
        disabled={isLoading || !image}
        className={`relative flex items-center justify-center px-6 py-3 rounded-lg font-medium transition-all duration-200 ${
          isLoading || !image
            ? 'bg-gray-400 cursor-not-allowed'
            : 'bg-blue-600 hover:bg-blue-700 active:bg-blue-800'
        } text-white shadow-lg hover:shadow-xl transform hover:-translate-y-0.5`}
      >
        {isLoading ? (
          <>
            <Spinner size="sm" color="white" className="mr-2" />
            <span>Processing...</span>
          </>
        ) : (
          <span>Upload & Detect</span>
        )}
      </button>

      {isLoading && (
        <div className="mt-4 p-4 bg-blue-50 border border-blue-200 rounded-lg">
          <div className="flex items-center justify-center space-x-3">
            <Spinner size="md" color="blue" />
            <div className="text-blue-700">
              <p className="font-medium">Analyzing X-Ray Image</p>
              <p className="text-sm opacity-75">Please wait while we process your image...</p>
            </div>
          </div>
        </div>
      )}

      {result && (
        <div className="mt-6">
          <h3 className="text-lg font-medium">Detection Result:</h3>
          <p className="text-xl text-green-600 font-bold">{result}</p>

          {detectedImageUrl && (
            <img
              src={detectedImageUrl}
              alt="Detected"
              className="mt-4 rounded shadow-lg"
            />
          )}
        </div>
      )}
    </div>
  );
}
