from django.db import models

# Create your models here.

class XRayResult(models.Model):
    image_path = models.CharField(max_length=255)
    result = models.CharField(max_length=64)
    uploaded_at = models.DateTimeField(auto_now_add=True)
    user = models.CharField(max_length=64, blank=True, null=True)  # Optional: can be replaced with ForeignKey

    def __str__(self):
        return f"{self.result} - {self.image_path} ({self.uploaded_at})"
