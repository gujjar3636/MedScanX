import { ArrowRight, Shield, Activity, Search, Zap, Database } from 'lucide-react';

const AboutUs = () => {
  return (
    <div className="bg-white">
      {/* Hero Section */}
      <div className="bg-gradient-to-br from-cyan-700 to-cyan-900 py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h1 className="text-4xl font-extrabold text-white tracking-tight sm:text-5xl">
            About MedScanX
          </h1>
          <p className="max-w-3xl mx-auto mt-6 text-xl text-cyan-100">
            Improving healthcare through advanced AI technology
          </p>
        </div>
      </div>

      {/* Main Content */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          <div>
            <h2 className="text-3xl font-bold text-gray-900">Our Mission</h2>
            <p className="mt-4 text-lg text-gray-600 leading-relaxed">
              At MedScanX, our mission is to transform healthcare diagnostics by making advanced AI-powered 
              analysis accessible to healthcare providers worldwide. We believe that by combining the expertise 
              of medical professionals with cutting-edge technology, we can improve diagnostic accuracy, 
              reduce time to treatment, and ultimately save lives.
            </p>
            <p className="mt-4 text-lg text-gray-600 leading-relaxed">
              Our platform is designed to be a valuable tool for radiologists, primary care physicians, and 
              specialists, serving as an additional layer of verification and assistance in the diagnostic 
              process. By providing fast, reliable analysis of chest X-rays, we aim to reduce diagnostic 
              error rates and help identify conditions that might otherwise be missed.
            </p>
          </div>
          <div className="rounded-xl overflow-hidden shadow-xl">
            <img 
              src="group1.png" 
              alt="Medical professionals using MedScanX" 
              className="w-full h-auto"
            />
          </div>
        </div>

        {/* Our Technology Section */}
        <div className="mt-20">
          <div className="text-center">
            <h2 className="text-3xl font-bold text-gray-900">Our Technology</h2>
            <p className="mt-4 max-w-3xl mx-auto text-lg text-gray-600">
              MedScanX uses advanced deep learning algorithms trained on millions of X-ray images to provide accurate and reliable diagnostic support.
            </p>
          </div>

          <div className="mt-12 grid grid-cols-1 md:grid-cols-3 gap-8">
            {/* Tech Feature 1 */}
            <div className="bg-white p-6 rounded-lg shadow-md border border-gray-100">
              <div className="h-12 w-12 flex items-center justify-center rounded-md bg-cyan-100 text-cyan-600 mb-4">
                <Database className="h-6 w-6" />
              </div>
              <h3 className="text-xl font-semibold text-gray-900">Vast Training Data</h3>
              <p className="mt-2 text-gray-600">
                Our AI models are trained on diverse datasets containing millions of labeled X-ray images from hospitals worldwide.
              </p>
            </div>

            {/* Tech Feature 2 */}
            <div className="bg-white p-6 rounded-lg shadow-md border border-gray-100">
              <div className="h-12 w-12 flex items-center justify-center rounded-md bg-cyan-100 text-cyan-600 mb-4">
                <Search className="h-6 w-6" />
              </div>
              <h3 className="text-xl font-semibold text-gray-900">Advanced Algorithms</h3>
              <p className="mt-2 text-gray-600">
                We employ state-of-the-art convolutional neural networks and vision transformers to detect and classify abnormalities.
              </p>
            </div>

            {/* Tech Feature 3 */}
            <div className="bg-white p-6 rounded-lg shadow-md border border-gray-100">
              <div className="h-12 w-12 flex items-center justify-center rounded-md bg-cyan-100 text-cyan-600 mb-4">
                <Shield className="h-6 w-6" />
              </div>
              <h3 className="text-xl font-semibold text-gray-900">Privacy First</h3>
              <p className="mt-2 text-gray-600">
                All patient data is processed with strict adherence to HIPAA and GDPR regulations, ensuring complete data privacy.
              </p>
            </div>
          </div>
        </div>

        {/* Our Team Section */}
        <div className="mt-20">
          <div className="text-center">
            <h2 className="text-3xl font-bold text-gray-900">Our Team</h2>
            <p className="mt-4 max-w-3xl mx-auto text-lg text-gray-600">
              MedScanX brings together experts in artificial intelligence, medicine, and healthcare technology.
            </p>
          </div>

          <div className="mt-12 grid grid-cols-1 md:grid-cols-3 gap-8">
            {/* Team Member 1 */}
            <div className="bg-white rounded-lg overflow-hidden shadow-md">
              <div className="h-64 bg-gray-200">
                <img 
                  src="/raza1.png" 
                  alt="Dr. Sarah Johnson" 
                  className="w-full h-full object-cover"
                />
              </div>
              <div className="p-6">
                <h3 className="text-xl font-semibold text-gray-900">Ch Ahmed Raza <br />Gujjar</h3>
                <p className="text-cyan-600">AI Engineer</p>
                <p className="mt-2 text-gray-600">
                  works on the AI model Training , LLM and the backend of the project.
                </p>
              </div>
            </div>

            {/* Team Member 2 */}
            <div className="bg-white rounded-lg overflow-hidden shadow-md">
              <div className="h-64 bg-gray-200">
                <img 
                  src="/hafsa.jpg" 
                  alt="Dr. Michael Chen" 
                  className="w-full h-full object-cover"
                />
              </div>
              <div className="p-6">
                <h3 className="text-xl font-semibold text-gray-900">Hafsa Ahmed</h3>
                <p className="text-cyan-600">AI Engineer</p>
                <p className="mt-2 text-gray-600">
                  AI researcher and works on frontend.
                </p>
              </div>
            </div>

            {/* Team Member 3 */}
            <div className="bg-white rounded-lg overflow-hidden shadow-md">
              <div className="h-64 bg-gray-200">
                <img 
                  src="/amna.jpg" 
                  alt="Dr. Alex Patel" 
                  className="w-full h-full object-cover"
                />
              </div>
              <div className="p-6">
                <h3 className="text-xl font-semibold text-gray-900">Amna Nadeem</h3>
                <p className="text-cyan-600">AI Engineer</p>
                <p className="mt-2 text-gray-600">
                  wroks on the documentations,frontend and Ai researcher in project.
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
      
      {/* Contact CTA */}
      <div className="bg-gray-50 py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl font-bold text-gray-900">Want to learn more?</h2>
          <p className="mt-4 text-lg text-gray-600 max-w-3xl mx-auto">
            We're happy to answer any questions you have about MedScanX and how it can benefit your healthcare practice.
          </p>
          <div className="mt-8">
            <button 
              onClick={() => window.location.href = '/contact'}
              className="inline-flex items-center px-6 py-3 border border-transparent text-base font-medium rounded-md text-white bg-cyan-600 hover:bg-cyan-700"
            >
              Contact Us
              <ArrowRight className="ml-2 h-5 w-5" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AboutUs;