// User Types
export interface User {
  id: string;
  name: string;
  email: string;
  profilePicture?: string;
}

// Authentication Types
export interface AuthState {
  user: User | null;
  isAuthenticated: boolean;
  isLoading: boolean;
  error: string | null;
}

export interface LoginCredentials {
  username: string;
  password: string;
}


export interface SignupCredentials {
  username: string;
  email: string;
  password: string;
  confirmPassword: string;
}

// X-Ray Image Types
export interface XRayImage {
  id: string;
  userId: string;
  imageUrl: string;
  uploadDate: Date;
  processed: boolean;
}

// Analysis Result Types
export interface AnalysisResult {
  id: string;
  xRayId: string;
  userId: string;
  result: 'Positive' | 'Negative' | 'Inconclusive';
  confidence: number;
  details: string;
  date: Date;
}

// Chat Types
export interface ChatMessage {
  id: string;
  userId: string;
  type: 'user' | 'bot';
  content: string;
  timestamp: Date;
}

export interface ChatSession {
  id: string;
  userId: string;
  messages: ChatMessage[];
  createdAt: Date;
  updatedAt: Date;
}